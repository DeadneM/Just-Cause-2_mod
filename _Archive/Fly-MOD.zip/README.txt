------------------------------------------------------------------------
rik00`s FLY-MOD

INSTALL:

*create a folder called "dropzone"(without"") in your JUST CAUSE 2 main FOLDER!(if the folder already exists do not create a second one !!)

*copy the .eez file in the dropzone folder

*restart Steam if mod dosent work

*HAVE FUN with rik00�s MOD

DO NOT UPLOAD ANYWHERE ELSE!!!

just send me a message if you have problems or if you want to work with me

:)
------------------------------------------------------------------------