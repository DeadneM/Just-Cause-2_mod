how To install, place file in dropzone folder.

