This mod removes the cirrus clouds in the upper atmosphere. Gives the sky a clearer look.
Works really good with ineedascotch HD clouds mod.
ZERO impact on performance.



TO INSTALL:

1. Create dropzone folder in your Just Cause 2 Main directory.
2. Place cirrus_clouds_dif.dds into Dropzone folder. (Should create /textures/weather folder)
3. Load game.
4. Done!




TO REMOVE:

DELETE cirrus_clouds_dif.dds from /dropzone/textures/weather folder


