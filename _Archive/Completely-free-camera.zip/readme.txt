Completely free camera

Extract camera_settings.bin to dropzone

You need to have the offical superman mod installed BEFORE installing the superman version of this mod!

V1.4:
-increased max angles for some stuff
-improved freefall cam behaviour
