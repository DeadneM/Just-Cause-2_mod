﻿JC2 Rebalanced Mod - Version 1.02
 By Kris J - www.krisjaydesigns.com (haven't been on for a while)

 I Made This For The PC (can be used on the PS3 also).
 This Mod Adds More Faction Fights, Chaos and Destruction and How the Game Environment (AI) Reacts Around You. The Cost of Blackmarket Items (chaos and money)
 and The Rewards You Will Receive For Completing Faction Missions has Been Changed (when you receive BM items and the cash rewards).
 It Also Includes a Few Cosmetic Changes Like Walking, a New On-Foot (over the shoulder) Camera Position and a Stronger Threshold to Damage (not god mode).Have Fun!


 <-- TO USE: UN-ZIP AND PUT THE 'JC2.Rebalanced-v1.02' FOLDER INTO YOUR 'DROPZONE'


 Items marked with a Double Asterisk (**) are New Features on Version 1.02


 MOD FEATURES

 - ** Factions Now Fighting Each Other on Land, Air and Sea. Some Epic Battles Can Happen Between the Factions and Army. (remove 'factions.bin' to disable).

 - ** Factions Spawn on Boats, Helicopters, Motorcycles and a Variety of Other Vehicles; Each with Their Own Faction Colors and Logos on Them.

 - Police/Army will Pay Less Attention To You (heat); UNLESS you Shoot At Them, Blow Shit Up, Drive Faction Vehicles, **Enter Restricted Areas or Shoot/Kill too many Civilians.

 - ** Police/Army Now Spawn With Better Quality Weapons (NO MORE sawed-off shotguns and MORE SMGs and Rifles).

 - Civilians Driving Vehicles Will Not Flee When Shot At - (small chance they will flee but not very often, usually in BIG gunfights they will). Civilians on Motorcycles/Open Air Vehicles Have A Higher Chance Of Fleeing Compared To Civilians In Cars/Trucks. 

 - Civilians Walking Around Will Not Flee/Become Frightened As Easy and Only Run Away When Shots Are Close To Them, if They're Shot At or if Cars Are Driving At Them.

 - More Money For Completing Faction Missions. I Increased This Because I didn't Understand Why You Would Get So Little Money For Doing Such 'High-Risk' Jobs (when every faction says you're the best at what you do and the prices for things at the BM).

 - Blackmarket Prices Have Become More 'Realistic' - Which Means The Price Reflects (Sort-of) What it Would Cost in The Real World. Does NOT change the DLC Prices.

 - The Loading Screen To Buy Things From The Blackmarket Has Been Removed For Quicker Access To Purchases (spend that extra money). I Kept The Helicopter Sounds Just For Fun.

 - The (Chaos) Levels Have Been Altered on the Different Vehicles and Weapons Available. This Changes When You Receive Them For Use On The Island.

 - More Ammunition is Available For Weapons in The Environment (from soldiers dropped guns and from crates).

 - A WALK MOD. So players on the PC that Use Keyboard/Mouse can Walk Around Instead Of Run. Hold 'L-Shift' To Sprint. (Remove the file 'basestatemachine.afsm' to disable).

 - Holster Your Weapon By Tapping 'L-Shift' Once While Walking (pushing up^). - This Will Work 95% Of The Time. You May Pull Your Weapon Back-Out When You Sprint and Stop. (not available if WALK MOD is Disabled).

 - The Camera Angle Has Been Moved Closer To The Player, Creating A More 'Over The Shoulder' Feel To The Game.

 - Damage Threshold Has Been Changed Giving You More Resistance To Damage and a Faster Health Regeneration Rate. This is NOT A GOD MODE, and YOU CAN STILL DIE.


I May Have Forgotten Some Functions I Changed, So You Might Find A few Other Things As You Play...

Let Me Know If You Would Like To See Anything Added To The Mod and I'll Try To Get It Put In.