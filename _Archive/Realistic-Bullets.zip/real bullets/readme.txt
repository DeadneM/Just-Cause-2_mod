Hello!!! 
Are you tired of those borring old yellow bullets?
Then try my realistic bullets!!!
they are just a small copper ball with some smoke!!!

Please do not criticise me... this is my second mod and I am planning on making more...

If you have any ideas put them in the comments for I have no imagination     :-)




This is for realism people only... if your do not want this type of bullet please do not comment.




