Just Cause 2 Battle Suit Rico v1.2 LS
-------------------------------------------------------------------------------------------
Author: FRX

Description:
Texture replacer for RICO (playable)
(no NPC change)

To play Rico in battlesuit outfit

v1.2 LS

- Reworked and higher resolution textures
- Backpack and pockets removed
- Long-sleeves added after requests (grapple kept)

Installation:
Extract to the subdirectory 'dropzone' of Just Cause 2' game folder

Remove :
Delete 'the "FRX-BattleRico1.2.LS" folder