Take "dropzone" and put it in the Just Cause 2 main folder.

If you have Steam, right-click on the Just Cause 2 entry, select "Properties", "Local Files", then "Browse Local Files". That will take you to the main folder.