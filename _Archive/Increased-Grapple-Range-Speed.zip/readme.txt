--------------------------
1) Details
--------------------------

This is a minor modification to increase the range of the grapple hook significantly, it won't be able to grapple you ridiculous lengths but it'll be able to grapple a building much further apart than the normal grapple would allow you to.

I've also slightly increased the speed of the grapple so you don't take forever to grapple to each location.

--------------------------
2) Installation Instructions
--------------------------

1. Place contents of zip file into "dropzone" folder located in main Just Cause 2 directory. If it doesn't exist then create it yourself by creating a new folder and naming it "dropzone" without quotes.

2. You can proceed to delete the readme when you have finished reading. It isn't a priority of the mod just a basic info document.

3. Launch Just Cause 2 and enjoy the modification.

--------------------------
3) Troubleshooting
--------------------------

- When you grapple either up in the sky or to somewhere out of the grapple range (unlikely but if so just move a little closer, it's the best I could do as it was quite frustrating getting it to work) then your grapple will bug and just stay on, to fix this simply grapple anywhere and it will remove itself.

- When falling you may have trouble grappling to the ground. (fixed)

Any other problems apart from the first should now be fixed.

--------------------------
4) Changelog 1.0 to 1.1
--------------------------

- Slightly decreased range of grapple to fix the not able to grapple while falling bug. You should also stick to walls if you were not able to before.

--------------------------
5) Credits
--------------------------

As this was a basic modification with only a few values edited I'm not going to take any credit, credit goes to the guy that made modification possible so things like these can easily be created for your benefit.

Version 1.1