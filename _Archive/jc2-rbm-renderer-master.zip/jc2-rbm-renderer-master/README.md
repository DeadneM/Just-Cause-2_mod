Download
=============
Latest version of RBMRender can be acquired from https://github.com/trixnz/jc2-rbm-renderer/releases/latest

Usage
==============
Open any archive (.tab) using the ```Open``` button.

Building
==============
The tool currently depends on Havok 5.5, which can be freely acquired from the Havok website. The ```HavokAnimations``` project is setup to look for Havok in the path ```D:\hk550\``` but this can be changed to suit your environment from within Visual Studio.

Additionally, you will need to drop the ```projects``` folder from http://svn.gib.me/builds/avalanche/avalanche-r171_b56.zip into the output directory.
