JustARC Reloaded version 0.61
2010 by CJay

This is a complete rewrite of my original JustARC tool. It's still in developement but works pretty good for now.

Features:
 - explore Just Cause 2 archives
 - DDS and text preview
 - extracts DDS files as a gazillion of formats
 - decompresses and opens Offzip/sarc files on the fly
 - Open files directly with the associated program
 - Search function
 - amazingly long loading times

Bugs:
 - Search for filename disabled (Takes ages and randomly crashed the tool, gotta look a bit into that)
 - Text preview doesn't work half of the time

New in 0.61:
 - Fixed bug with Offzip's that didn't contain sarc files. (It lets you save the decompressed file now.)
 - Fixed a bug where the texture extractor didn't work in SARC files.

If the tool crashes, please send an error report using the inbuilt reporting tool. Thanks!

Disclaimer:
I'm not responsible for any damage that could result from the usage of this program. (Not that anything could happen, but better safe than sorry I guess.)