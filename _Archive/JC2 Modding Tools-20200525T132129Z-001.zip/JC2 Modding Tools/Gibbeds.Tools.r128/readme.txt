Uses icons from the 'Fugue' pack available at: http://p.yusukekamiyamane.com/

Changes from the SVN version 128 trunk:
.\bin\projects\The Hunter.xml - Updated to fix install path detection
.\bin\readme.txt              - Updated to the file you're currently reading.
.\bin\rev128.txt              - Added
.\bin\HowToUpdate.txt         - added
.\docs                        - Moved to .\bin\docs
