JustARC Reloaded version 0.6a
2010 by CJay

This is a complete rewrite of my original JustARC tool. It's still in developement but works pretty good for now.

Features:
 - explore Just Cause 2 archives
 - DDS and text preview
 - decompresses and opens Offzip/sarc files on the fly
 - Open files directly with the associated program
 - Search function
 - amazingly long loading times

Bugs:
 - Fucks up when opening some offzip files (They dont contain anything interesting anyway (I think))
 - Search for filename disabled (Takes ages and randomly crashed the tool, gotta look a bit into that)
 - Text preview doesn't work half of the time

If the tool crashes, please send an error report using the inbuilt reporting tool. Thanks!

Disclaimer:
I'm not responsible for any damage that could result from the usage of this program. (Not that anything could happen, but better safe than sorry I guess.)