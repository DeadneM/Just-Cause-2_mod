#ifndef __GAME_HPP
#define __GAME_HPP

bool GameHook();

#endif
