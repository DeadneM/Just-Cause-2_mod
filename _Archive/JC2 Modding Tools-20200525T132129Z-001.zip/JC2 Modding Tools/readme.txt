This archive is a compilation of available tools for Just Cause 2 that I personally use, conveniently packaged for anybody to use.

CREDS/SHOUTS:
Gibbed's Toolkit was created by Gibbed (Rick), JustARC by CJay, I merely compiled r171 and packaged them all together for convenience.  The JCCE included was uploaded by Nicholas Roth to JustCause2Mods.com. FSBExt by Luigi Auriemma, and FSBExtractor by Aezay.


CONTENTS:
Gibbed's Toolkit r128 - original binaries from justcause2mods.com
Gibbed's Toolkit r169 - original binaries from justcause2mods.com
Gibbed's Toolkit r171 - compiled from the "current" source SVN

JustARC 061 - original binaries from justcause2mods.com
JustARC 06a - original binaries from justcause2mods.com

JCCE (Just Cause Content Editor) - binaries from justcause2mods.com

FSBExt 
FSBExtract

NOTES:
-Apparently there was a format change from r128 to r169, some older format .xml code mods will compile properly with this.  There is a older model viewer in r128 that seems to work better (with some .rbms) than the newer r169+ versions.
-JustARC is awesome for raw extraction of data from .arc/.tab files, usefull where Gibbed's archive viewer doesn't work.
-JCCE is another usefull tool like JustARC, included for convenience.
-Compiled and tested on my own system, should work fine on others (intel x3220, 8gb ram, gtx460, win7 x64 sp1, etc..), I've been using it for a while no problems.  
-Incase of problems, you may need some prequesites (.net framework, xla, etc..)
-Personally I haven't seen any difference with r171 vs r169 (haven't found the changelog), but it's compiled and works.
-FSBExt/FSBExtract are usefull for checking out/extracting audio files.  I believe to recreate FSB files, you'd need something like FMOD Event Player (more info needed).

QUICK USAGE/"INSTALL" NOTES:
-Unpack the archive somewher you'll find it - like Desktop/JC2 or something.
-Inside each folder you'll find the binaries for each toolkit, as well as original README.TXT
-Inside any version of Gibbed's toolkit, you'll find a docs folder with good info.
-For converting files to .xml - simply drag the desired file (something.bin) onto Gibbed.Avalanche.BinConvert.exe and it will convert the file into .xml and place it into the same folde as the .bin file originally was.
-R169+ seems to support more files for binconvert, I've converted the following (to give you an idea of what you can crack open): .bin, .blo, .bl, .ee.epe, .mvdoll, .cdoll, .event_trackb, .aiteam, and more.  Check here for other file extensions: http://justcause.wikia.com/wiki/File_Extensions


BINCONVERT CRASHES:
-If the tool crashes when converting a .bin file to .xml, the file has been "locked" by its original modder.  There are ways to "remove" the locks and allow the file to be properly converted, viwed and recompiled.  Currently I won't disclose how to remove the locks, however it's actually very simple - but my suggestion is to try and contact the original modder and request their modded source.
-If the tool crashes when converting an .xml back to its original container, before hitting "close" look at the command prompt window and see if you can identify where (it usually says the line/col the error occoured).
-You may have to run the program from a command prompt if its still too hard to see the output, double check any object id="hexaddress" and object name="stringname" switching those by accident will cause crashes without line #'s.

Anything else, search away.  Google, JustCause2Mods forums, etc...  Have a good one all!