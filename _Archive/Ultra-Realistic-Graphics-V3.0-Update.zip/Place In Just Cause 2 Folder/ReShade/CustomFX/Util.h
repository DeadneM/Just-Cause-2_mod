//Stuff all/most of CustomFX shared shaders need
NAMESPACE_ENTER(CFX)
#define CFX_SETTINGS_DEF "ReShade/CustomFX.cfg"
#define CFX_SETTINGS_UNDEF "ReShade/CustomFX.undef" 

#include CFX_SETTINGS_DEF

//put your custom stuff here

#include CFX_SETTINGS_UNDEF
NAMESPACE_LEAVE()